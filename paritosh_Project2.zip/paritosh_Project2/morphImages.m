%% This script executes the image morphing with barycentric coordinates

